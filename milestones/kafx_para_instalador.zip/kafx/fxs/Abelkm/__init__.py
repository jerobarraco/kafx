 
"""Este archivo es encesario para poder importar los modulos en esta carpeta
desde python, entones python reconoce la carpeta Tutoriales como si fuese un
modulo.
por ejemplo tenemos las carpetas fxs/Tutoriales y adentro el archivo
Encadenado.py
entonces podemos cargar encadenado usando
import fxs.Tutoriales.Encadenado
"""
